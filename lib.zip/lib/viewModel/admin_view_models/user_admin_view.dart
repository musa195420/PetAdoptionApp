import 'package:flutter/material.dart';
import '../../models/selection_box_model.dart';

class UserAdminViewModel extends ChangeNotifier {
 
}
