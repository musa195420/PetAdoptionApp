
class ApiStatus{
  dynamic data;
  String? error;
  String errorCode;
  ApiStatus({this.data, required this.errorCode, this.error});
}