import 'package:flutter/material.dart';
import 'package:petadoption/viewModel/admin_view_models/user_admin_view.dart';
import 'package:provider/provider.dart';

class UserAdmin extends StatelessWidget {
  UserAdmin({super.key});
  final scaffoldKey = GlobalKey<ScaffoldState>();

  List<String> roles = ["Adopter", "Donor", "Admin"];

  @override
  Widget build(BuildContext context) {
  UserAdminViewModel viewModel = context.watch<UserAdminViewModel>();

    return Scaffold(
      key: scaffoldKey,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            'assets/images/bg.png',
            fit: BoxFit.cover,
          ),
          // Login form content with SafeArea
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    // Character image at top
                 
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

 
}
